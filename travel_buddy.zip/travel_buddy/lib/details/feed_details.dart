import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:travel_buddy/details/feedCityDetails.dart';

class FeedDetails extends StatefulWidget {
  final String docId;
  FeedDetails({Key? key, required this.docId}) : super(key: key);

  @override
  State<FeedDetails> createState() => _FeedDetailsState();
}

class _FeedDetailsState extends State<FeedDetails> {
  @override
  Widget build(BuildContext context) {
    final users = FirebaseFirestore.instance
        .collection('Feed')
        .doc(widget.docId)
        .collection("march")
        .get();

    return FutureBuilder<QuerySnapshot>(
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text("No Data to Display");
          }

          return ListView(
              children: snapshot.data!.docs.map((DocumentSnapshot ds) {
            Map<String, dynamic> feed =
                ds.data()! as Map<String, dynamic>; // firestore indivi data

            return GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, FeedCityDetails.DETAILS_ROUTE,
                    arguments: {'FeedDetails': feed});
              },
              child: Card(
                  elevation: 9,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 200,
                        width: 300,
                        child: Image.network(
                          feed['place_image'].toString(),
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text('${feed['place_name']}')
                    ],
                  )),
            );
          }).toList());
        },
        future: users);
  }
}
