class ConstantData {
  static const String UID = 'user-id';
}
