package com.example.travel_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
